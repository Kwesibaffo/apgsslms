<center>
		<footer>
		
		<p style="color:whitesmoke;">APGSS  Copyright &copy; <?php echo date('Y')?></p>
			<!-- <p>Programmed by: John Kevin Lorayna BSIS 4-A</p> -->
		</footer>
</center>

