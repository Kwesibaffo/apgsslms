				
					<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/Logo.png">
						</div>	
						<div class="span8">
						
								<div class="title">
							
							<h4 >
                            <p style="color: white;font-size: 15px;font-weight: bold;">ARCHBISHOP PORTERS GIRL'S SECONDRY SCHOOL</p>
							
						
							</h4>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p> </p>
												<marquee   direction = "left" loop=""><p>WELCOME TO APGSS STUDENT LMS</p></marquee>
												
								</div>		
						</div>		
				</div>