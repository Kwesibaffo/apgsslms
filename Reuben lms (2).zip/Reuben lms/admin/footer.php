<div class="pull-right">
        <footer>
           <p style="color:white!important;">AlL RIGHT RESERVED APGSS &copy; <?php echo date("Y");?> </p>
        <footer>
</div>