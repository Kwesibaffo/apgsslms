<?php
$conn = mysqli_connect('localhost','root','','lmsdb') or die(mysqli_error());
?>